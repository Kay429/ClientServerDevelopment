#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 19 15:47:25 2023
Last updated Sun Sep 24 01:15:35 2023

@author: kayleighkinse_snhu
"""

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in the AAC Database"""

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30790
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        try:
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except:
            print("AUTHENTICATION FAILED!")
            print("Please reinstantiate AnimalShelter() instance with correct username and password!")

    # Create method implements the C in CRUD.
    def create(self, data) -> bool:
        """ Adds a new document to the database.
            Returns True if the insert was successful """
        if data is not None:
            if type(data) is dict:
                return bool(self.database.animals.insert_one(data))
            else :
                raise Exception("data must be a dictionary value")
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Read method implements the R in CRUD
    def read(self, query) -> list:
        """ Searches for documents matching query and
            returns results as a list.
            If no results, returns an empty list."""
        if query is not None:
            if type(query) is dict:
                resultCursor = self.database.animals.find(query)
                return resultCursor
            
                #Create list from resultCursor
                if resultCursor:
                    resultList = []
                    for document in resultCursor:
                        resultList.append(document)
                    return resultList
                else:
                    return []
            else :
                raise Exception("query must be a dictionary value")
        else:
            raise Exception("Cannot search because query parameter is empty")
            
    # Update method implements the U in CRUD
    def update(self, query, updateData) -> int:
        """ Searches for documents that match query and
            updates them with updateData.
            updateData must be in format {'$set' : {}}
            where {} contains the update data.
            Returns the number of documents updated."""
        if query is not None and updateData is not None:
            if type(query) is dict and type(updateData) is dict:
                # updateData needs to be in the correct format
                if "$set" in  updateData and type(updateData.get("$set")) is dict:
                    # Count the number of documents to update
                    numResults = self.database.animals.count_documents(query)
                    # Perform update
                    if numResults == 1:
                        self.database.animals.update_one(query, updateData)
                    elif numResults > 1:
                        self.database.animals.update_many(query, updateData)
                    return numResults
                else:
                    raise Exception("updateDate needs to be a key-value pair with '$set' as the key and another dict as the value.")
            else:
                raise Exception("Arguments must be dictionary values")
        else:
            raise Exception("Cannot update due to empty argument(s)")
            
    # Delete method implements the D in CRUD
    def delete(self, query) -> int:
        """ Searches for and deletes documents matching query.
            Returns the number of documents deleted."""
        if query is not None:
            if type(query) is dict:
                # Count the number of documents to delete
                numResults = self.database.animals.count_documents(query)
                if numResults == 1:
                    self.database.animals.delete_one(query)
                elif numResults > 1:
                    self.database.animals.delete_many(query)
                return numResults
            else:
                raise Exception("query must be a dictionary value")
        else:
            raise Exception("Cannot search because query parameter is empty")